<img src="{{ asset('images/logo.png') }}"
     {{ $attributes->merge(['class' => 'h-full w-full object-contain']) }}
     alt="\PLC HUB Logo">
